url_s= {"Whatsapp": {"url": "https://wa.me/message/SO5PQ5JDW3DII1", "icon": "/whatsapp.png"},
  "Instagram": {"url": "https://www.instagram.com/mcvifth?utm_source=qr&igsh=MWZtN2poY2RjdzdhZg==", "icon": "/insta.jpg"},
 "Threads": {"url": "https://www.threads.net/@mcvifth", "icon": "/threads.jpg"},
"Tiktok": {"url": "https://www.tiktok.com/@mcvifth_pedhope?_t=ZM-8tV7T19bsPN&_r=1", "icon":"/tiktok.jpg"},
"Snapchat": {"url": "https://www.snapchat.com/add/mcvifth_pedhope?share_id=6ghkTuCzmWI&locale=en-US", "icon":"/snap.png"}}