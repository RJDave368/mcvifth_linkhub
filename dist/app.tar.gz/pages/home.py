import flet as ft
import random
from assets import bio
from assets import urls as url_s

class Link(ft.Container):
    def __init__(self, site_name, url_link, icon_path, color):
        super().__init__(width=180, padding=5, height=50, border_radius=4, col=6)
        self.url = url_link

        color_ = color
        self.color_ = color

        self.border = ft.border.all(0.4, color_)

        self.site_name = site_name
        self.icon_path = icon_path

        self.icon_image = ft.Image(src=icon_path, fit=ft.ImageFit.CONTAIN, border_radius=130)
        self.site_text = ft.Text(self.site_name, weight=ft.FontWeight.BOLD)

        self.content = ft.Row([self.icon_image, self.site_text])

        self.bgcolor = color_

        self.on_hover = self.hover_effect

    def hover_effect(self, e):
        if self.width == 180:
            self.width = 190
            self.height = 60
            self.border = ft.border.all(0.8, self.color_)
            e.page.update()
        else:
            self.width = 180
            self.height = 50
            self.border = ft.border.all(0.4, self.color_)
            e.page.update()

class Profile(ft.Container):
    def __init__(self, path):
        super().__init__(width=220, height=220, shape=ft.BoxShape.CIRCLE, padding=20)

        self.image_src = path
        self.image_fit = ft.ImageFit.FIT_WIDTH

class Bio(ft.Container):
    def __init__(self, username, bio):
        super().__init__(padding=10)

        self.content = ft.Column([
            ft.Row([ft.Text(username, weight=ft.FontWeight.BOLD, size=21, width=300)], ft.MainAxisAlignment.CENTER, width=250),
            ft.Row([ft.Text(bio, overflow=ft.TextOverflow.CLIP, width=300)], ft.MainAxisAlignment.CENTER, width=250)
        ])

class Home(ft.Container):
    def __init__(self, page):
        super().__init__(expand=True, border_radius=3, margin=-10, padding=25)
        self.image_src = "/bg.jpg"
        self.image_fit = ft.ImageFit.FILL
        self.alignment = ft.alignment.center

        exhibition_width = 370

        self.exhibition = ft.ResponsiveRow(width=exhibition_width)
        self.bio = Bio(bio.bio_info["username"], bio.bio_info["bio"])
        self.profile_ting = Profile("/dp.jpg")
        self.profile = ft.Column([self.profile_ting, self.bio])


        colors = [ft.Colors.BLACK26, ft.Colors.OUTLINE, ft.Colors.BLACK45, ft.Colors.WHITE24, ft.Colors.WHITE54, ft.Colors.INVERSE_PRIMARY]
        chosen_color = random.choice(colors)

        self.profile_ting.border = ft.border.all(1, chosen_color)

        urls = url_s.url_s

        for site in urls:
            self.exhibition.controls.append(Link(site, urls[site]["url"], urls[site]["icon"], chosen_color))

        self.content = ft.ListView([
            ft.Row([self.profile], ft.MainAxisAlignment.CENTER),
            ft.Row([self.exhibition], ft.MainAxisAlignment.CENTER)
        ], spacing=50, expand=True)