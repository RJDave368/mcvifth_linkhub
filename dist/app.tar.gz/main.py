import flet as ft
import views

def main(page: ft.Page):
    page.title = "McVifth Pedhope - Socials"
    page.theme_mode = ft.ThemeMode.DARK
    page.adaptive = True
    page.horizontal_alignment = ft.MainAxisAlignment.CENTER
    page.window.center()

    page.update()

    def route_change(route):
        page.views.clear()
        page.views.append(views.views_handler(page)[page.route])
        page.update()

    page.on_route_change = route_change

    page.go("/")

    page.update()

ft.app(target=main, assets_dir="assets")
