import flet as ft
from pages.home import Home

def views_handler(page: ft.Page):
    return {"/": ft.View("/", controls=[Home(page)], adaptive=True, horizontal_alignment=ft.CrossAxisAlignment.CENTER)}